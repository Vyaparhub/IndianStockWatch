import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { QuarterlyResult } from "@shared/schema";

interface QuarterlyResultsProps {
  results: QuarterlyResult[];
}

export function QuarterlyResults({ results }: QuarterlyResultsProps) {
  if (!results || results.length === 0) {
    return (
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Quarterly Results</h2>
        <p className="text-muted-foreground">No quarterly data available</p>
      </Card>
    );
  }

  const sortedResults = [...results].sort((a, b) => {
    if (a.year !== b.year) return b.year - a.year;
    const quarters = ["Q1", "Q2", "Q3", "Q4"];
    return quarters.indexOf(b.quarter) - quarters.indexOf(a.quarter);
  });

  const formatCurrency = (value: string) => {
    const num = parseFloat(value);
    return `₹${(num / 100).toFixed(2)} Cr`;
  };

  return (
    <Card className="p-6">
      <h2 className="text-xl font-semibold mb-6">Quarterly Results</h2>
      <ScrollArea className="w-full">
        <div className="border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-xs font-medium uppercase tracking-wide">Quarter</TableHead>
                <TableHead className="text-xs font-medium uppercase tracking-wide text-right font-mono">Revenue</TableHead>
                <TableHead className="text-xs font-medium uppercase tracking-wide text-right font-mono">Profit</TableHead>
                <TableHead className="text-xs font-medium uppercase tracking-wide text-right font-mono">EPS (₹)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedResults.map((result) => {
                const profit = parseFloat(result.profit);
                const isPositive = profit >= 0;

                return (
                  <TableRow key={result.id} data-testid={`row-quarter-${result.quarter}-${result.year}`}>
                    <TableCell className="font-medium">
                      {result.quarter} FY{result.year}
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {formatCurrency(result.revenue)}
                    </TableCell>
                    <TableCell className={`text-right font-mono ${isPositive ? 'text-positive' : 'text-negative'}`}>
                      {formatCurrency(result.profit)}
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      ₹{parseFloat(result.eps).toFixed(2)}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </ScrollArea>
    </Card>
  );
}
