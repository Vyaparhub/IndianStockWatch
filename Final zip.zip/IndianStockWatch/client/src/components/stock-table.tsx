import { Link } from "wouter";
import { Star, TrendingUp, TrendingDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import type { Stock } from "@shared/schema";

interface StockTableProps {
  stocks: Stock[];
  isLoading?: boolean;
  watchlist?: Set<string>;
  onToggleWatchlist?: (stockId: string) => void;
}

export function StockTable({ stocks, isLoading, watchlist, onToggleWatchlist }: StockTableProps) {
  const formatNumber = (value: string | number, decimals = 2) => {
    const num = typeof value === "string" ? parseFloat(value) : value;
    return num.toLocaleString("en-IN", { 
      minimumFractionDigits: decimals, 
      maximumFractionDigits: decimals 
    });
  };

  const formatMarketCap = (value: string | number) => {
    const num = typeof value === "string" ? parseFloat(value) : value;
    if (num >= 1_00_000) {
      return `₹${(num / 1_00_000).toFixed(2)}L Cr`;
    }
    if (num >= 1_000) {
      return `₹${(num / 1_000).toFixed(2)}K Cr`;
    }
    return `₹${num.toFixed(2)} Cr`;
  };

  const formatVolume = (value: string | number) => {
    const num = typeof value === "string" ? parseFloat(value) : value;
    if (num >= 1_00_00_000) {
      return `${(num / 1_00_00_000).toFixed(2)}Cr`;
    }
    if (num >= 1_00_000) {
      return `${(num / 1_00_000).toFixed(2)}L`;
    }
    if (num >= 1_000) {
      return `${(num / 1_000).toFixed(2)}K`;
    }
    return num.toString();
  };

  if (isLoading) {
    return (
      <div className="space-y-2">
        {[...Array(8)].map((_, i) => (
          <Skeleton key={i} className="h-12 w-full" />
        ))}
      </div>
    );
  }

  if (!stocks || stocks.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="text-muted-foreground mb-2">No stocks found</div>
        <p className="text-sm text-muted-foreground">Try adjusting your filters or search query</p>
      </div>
    );
  }

  return (
    <div className="border rounded-md overflow-hidden">
      <Table>
        <TableHeader className="sticky top-0 bg-card z-10">
          <TableRow className="hover:bg-transparent border-b border-border">
            {onToggleWatchlist && <TableHead className="w-12"></TableHead>}
            <TableHead className="text-xs font-medium uppercase tracking-wide">STOCK NAME</TableHead>
            <TableHead className="text-xs font-medium uppercase tracking-wide">SYMBOL</TableHead>
            <TableHead className="text-xs font-medium uppercase tracking-wide text-right font-mono">PRICE (₹)</TableHead>
            <TableHead className="text-xs font-medium uppercase tracking-wide text-right font-mono">CHANGE (₹)</TableHead>
            <TableHead className="text-xs font-medium uppercase tracking-wide text-right font-mono">% CHANGE</TableHead>
            <TableHead className="text-xs font-medium uppercase tracking-wide text-right font-mono">VOLUME</TableHead>
            <TableHead className="text-xs font-medium uppercase tracking-wide text-right font-mono">MARKET CAP</TableHead>
            <TableHead className="text-xs font-medium uppercase tracking-wide text-right font-mono">P/E</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {stocks.map((stock) => {
            const change = parseFloat(stock.change);
            const changePercent = parseFloat(stock.changePercent);
            const isPositive = change >= 0;
            const isInWatchlist = watchlist?.has(stock.id);

            return (
              <TableRow 
                key={stock.id} 
                className="hover-elevate cursor-pointer group"
                data-testid={`row-stock-${stock.id}`}
              >
                {onToggleWatchlist && (
                  <TableCell className="w-12">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleWatchlist(stock.id);
                      }}
                      data-testid={`button-watchlist-${stock.id}`}
                      className="h-8 w-8"
                    >
                      <Star 
                        className={`h-4 w-4 ${isInWatchlist ? 'fill-primary text-primary' : ''}`}
                      />
                    </Button>
                  </TableCell>
                )}
                <TableCell className="font-medium">
                  <Link href={`/stock/${stock.id}`} className="hover:underline">
                    <span data-testid={`text-stock-name-${stock.id}`}>{stock.name}</span>
                  </Link>
                </TableCell>
                <TableCell>
                  <Link href={`/stock/${stock.id}`}>
                    <code className="text-sm text-muted-foreground" data-testid={`text-stock-symbol-${stock.id}`}>
                      {stock.symbol}
                    </code>
                  </Link>
                </TableCell>
                <TableCell className="text-right font-mono" data-testid={`text-price-${stock.id}`}>
                  <Link href={`/stock/${stock.id}`}>
                    {formatNumber(stock.price)}
                  </Link>
                </TableCell>
                <TableCell className={`text-right font-mono ${isPositive ? 'text-positive' : 'text-negative'}`} data-testid={`text-change-${stock.id}`}>
                  <Link href={`/stock/${stock.id}`} className="flex items-center justify-end gap-1">
                    {isPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                    {isPositive ? '+' : ''}{formatNumber(change)}
                  </Link>
                </TableCell>
                <TableCell className={`text-right font-mono ${isPositive ? 'text-positive' : 'text-negative'}`} data-testid={`text-change-percent-${stock.id}`}>
                  <Link href={`/stock/${stock.id}`}>
                    {isPositive ? '+' : ''}{formatNumber(changePercent)}%
                  </Link>
                </TableCell>
                <TableCell className="text-right font-mono" data-testid={`text-volume-${stock.id}`}>
                  <Link href={`/stock/${stock.id}`}>
                    {formatVolume(stock.volume)}
                  </Link>
                </TableCell>
                <TableCell className="text-right font-mono" data-testid={`text-market-cap-${stock.id}`}>
                  <Link href={`/stock/${stock.id}`}>
                    {formatMarketCap(stock.marketCap)}
                  </Link>
                </TableCell>
                <TableCell className="text-right font-mono" data-testid={`text-pe-${stock.id}`}>
                  <Link href={`/stock/${stock.id}`}>
                    {stock.peRatio ? formatNumber(stock.peRatio) : '-'}
                  </Link>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
