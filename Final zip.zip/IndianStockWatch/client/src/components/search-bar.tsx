import { useState, useEffect, useRef } from "react";
import { Search, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Command, CommandEmpty, CommandGroup, CommandItem, CommandList } from "@/components/ui/command";
import { useLocation } from "wouter";
import type { Stock } from "@shared/schema";

interface SearchBarProps {
  stocks: Stock[];
  onSearch: (query: string) => void;
}

export function SearchBar({ stocks, onSearch }: SearchBarProps) {
  const [query, setQuery] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [, setLocation] = useLocation();
  const inputRef = useRef<HTMLInputElement>(null);

  const filteredStocks = query.trim() 
    ? stocks.filter(stock => 
        stock.name.toLowerCase().includes(query.toLowerCase()) ||
        stock.symbol.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 5)
    : [];

  useEffect(() => {
    const timer = setTimeout(() => {
      onSearch(query);
    }, 300);

    return () => clearTimeout(timer);
  }, [query, onSearch]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (inputRef.current && !inputRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSelect = (stockId: string) => {
    setQuery("");
    setIsOpen(false);
    setLocation(`/stock/${stockId}`);
  };

  const handleClear = () => {
    setQuery("");
    onSearch("");
    inputRef.current?.focus();
  };

  return (
    <div className="relative w-full max-w-xl" ref={inputRef}>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
        <Input
          type="search"
          placeholder="Search stocks by name or symbol..."
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          className="pl-10 pr-10"
          data-testid="input-search"
        />
        {query && (
          <Button
            size="icon"
            variant="ghost"
            onClick={handleClear}
            className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7"
            data-testid="button-clear-search"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {isOpen && query.trim() && (
        <div className="absolute top-full mt-2 w-full bg-popover border border-popover-border rounded-md shadow-lg z-50">
          <Command>
            <CommandList>
              {filteredStocks.length > 0 ? (
                <CommandGroup heading="Stocks">
                  {filteredStocks.map((stock) => {
                    const change = parseFloat(stock.changePercent);
                    const isPositive = change >= 0;
                    
                    return (
                      <CommandItem
                        key={stock.id}
                        onSelect={() => handleSelect(stock.id)}
                        className="flex items-center justify-between gap-4 cursor-pointer"
                        data-testid={`search-result-${stock.id}`}
                      >
                        <div className="flex flex-col">
                          <span className="font-medium">{stock.name}</span>
                          <code className="text-xs text-muted-foreground">{stock.symbol}</code>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-sm">₹{parseFloat(stock.price).toFixed(2)}</span>
                          <span className={`font-mono text-xs ${isPositive ? 'text-positive' : 'text-negative'}`}>
                            {isPositive ? '+' : ''}{change.toFixed(2)}%
                          </span>
                        </div>
                      </CommandItem>
                    );
                  })}
                </CommandGroup>
              ) : (
                <CommandEmpty>No stocks found</CommandEmpty>
              )}
            </CommandList>
          </Command>
        </div>
      )}
    </div>
  );
}
