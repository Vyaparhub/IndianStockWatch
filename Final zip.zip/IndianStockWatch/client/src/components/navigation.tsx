import { Link, useLocation } from "wouter";
import { Search, Filter, Star, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Navigation() {
  const [location] = useLocation();

  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  return (
    <nav className="flex items-center gap-2">
      <Link href="/">
        <Button 
          variant={isActive("/") && !location.includes("/stock/") ? "default" : "ghost"}
          data-testid="nav-home"
        >
          <Search className="h-4 w-4 mr-2" />
          Home
        </Button>
      </Link>
      <Link href="/screener">
        <Button 
          variant={isActive("/screener") ? "default" : "ghost"}
          data-testid="nav-screener"
        >
          <Filter className="h-4 w-4 mr-2" />
          Screener
        </Button>
      </Link>
      <Link href="/watchlist">
        <Button 
          variant={isActive("/watchlist") ? "default" : "ghost"}
          data-testid="nav-watchlist"
        >
          <Star className="h-4 w-4 mr-2" />
          Watchlist
        </Button>
      </Link>
      <Link href="/comparison">
        <Button 
          variant={isActive("/comparison") ? "default" : "ghost"}
          data-testid="nav-comparison"
        >
          <TrendingUp className="h-4 w-4 mr-2" />
          Compare
        </Button>
      </Link>
    </nav>
  );
}
