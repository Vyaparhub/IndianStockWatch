import { Card } from "@/components/ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";
import type { Financial } from "@shared/schema";

interface FinancialMetricsProps {
  financials: Financial[];
}

export function FinancialMetrics({ financials }: FinancialMetricsProps) {
  if (!financials || financials.length === 0) {
    return (
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Financial Metrics</h2>
        <p className="text-muted-foreground">No financial data available</p>
      </Card>
    );
  }

  const latestFinancial = financials.sort((a, b) => b.year - a.year)[0];

  const metrics = [
    {
      label: "Revenue",
      value: parseFloat(latestFinancial.revenue),
      format: (v: number) => `₹${(v / 100).toFixed(2)} Cr`,
      year: latestFinancial.year,
    },
    {
      label: "Profit",
      value: parseFloat(latestFinancial.profit),
      format: (v: number) => `₹${(v / 100).toFixed(2)} Cr`,
      year: latestFinancial.year,
      isPositive: parseFloat(latestFinancial.profit) > 0,
    },
    {
      label: "EPS",
      value: parseFloat(latestFinancial.eps),
      format: (v: number) => `₹${v.toFixed(2)}`,
      year: latestFinancial.year,
    },
    {
      label: "ROE",
      value: parseFloat(latestFinancial.roe),
      format: (v: number) => `${v.toFixed(2)}%`,
      year: latestFinancial.year,
      isPositive: parseFloat(latestFinancial.roe) > 15,
    },
    {
      label: "Debt/Equity",
      value: parseFloat(latestFinancial.debtToEquity),
      format: (v: number) => v.toFixed(2),
      year: latestFinancial.year,
      isPositive: parseFloat(latestFinancial.debtToEquity) < 1,
    },
  ];

  return (
    <Card className="p-6">
      <h2 className="text-xl font-semibold mb-6">Financial Metrics</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {metrics.map((metric) => (
          <div key={metric.label} className="space-y-1" data-testid={`metric-${metric.label.toLowerCase().replace(/\//g, '-')}`}>
            <div className="text-sm text-muted-foreground">{metric.label}</div>
            <div className="flex items-baseline gap-2">
              <div className={`text-2xl font-semibold font-mono ${
                metric.isPositive !== undefined 
                  ? metric.isPositive ? 'text-positive' : 'text-negative'
                  : ''
              }`}>
                {metric.format(metric.value)}
              </div>
              {metric.isPositive !== undefined && (
                <div className={metric.isPositive ? 'text-positive' : 'text-negative'}>
                  {metric.isPositive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                </div>
              )}
            </div>
            <div className="text-xs text-muted-foreground">FY {metric.year}</div>
          </div>
        ))}
      </div>
    </Card>
  );
}
