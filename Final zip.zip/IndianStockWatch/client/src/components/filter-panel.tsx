import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";

export interface FilterValues {
  marketCapMin: number;
  marketCapMax: number;
  peRatioMin: number;
  peRatioMax: number;
  roeMin: number;
  roeMax: number;
  debtToEquityMax: number;
}

interface FilterPanelProps {
  onFilterChange: (filters: FilterValues) => void;
  activeFilterCount: number;
}

export function FilterPanel({ onFilterChange, activeFilterCount }: FilterPanelProps) {
  const [filters, setFilters] = useState<FilterValues>({
    marketCapMin: 0,
    marketCapMax: 1000000,
    peRatioMin: 0,
    peRatioMax: 100,
    roeMin: 0,
    roeMax: 50,
    debtToEquityMax: 5,
  });

  const handleApply = () => {
    onFilterChange(filters);
  };

  const handleReset = () => {
    const defaultFilters: FilterValues = {
      marketCapMin: 0,
      marketCapMax: 1000000,
      peRatioMin: 0,
      peRatioMax: 100,
      roeMin: 0,
      roeMax: 50,
      debtToEquityMax: 5,
    };
    setFilters(defaultFilters);
    onFilterChange(defaultFilters);
  };

  const formatMarketCap = (value: number) => {
    if (value >= 100000) return `₹${(value / 100000).toFixed(0)}L Cr`;
    if (value >= 1000) return `₹${(value / 1000).toFixed(0)}K Cr`;
    return `₹${value} Cr`;
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold">Filters</h2>
        {activeFilterCount > 0 && (
          <Badge variant="secondary" data-testid="badge-filter-count">
            {activeFilterCount} active
          </Badge>
        )}
      </div>

      <div className="space-y-6">
        <div className="space-y-3">
          <Label className="text-sm font-medium">Market Cap (Cr)</Label>
          <div className="space-y-2">
            <Slider
              value={[filters.marketCapMin, filters.marketCapMax]}
              onValueChange={([min, max]) => setFilters({ ...filters, marketCapMin: min, marketCapMax: max })}
              min={0}
              max={1000000}
              step={1000}
              className="w-full"
              data-testid="slider-market-cap"
            />
            <div className="flex items-center justify-between text-xs text-muted-foreground font-mono">
              <span>{formatMarketCap(filters.marketCapMin)}</span>
              <span>{formatMarketCap(filters.marketCapMax)}</span>
            </div>
          </div>
        </div>

        <Separator />

        <div className="space-y-3">
          <Label className="text-sm font-medium">P/E Ratio</Label>
          <div className="space-y-2">
            <Slider
              value={[filters.peRatioMin, filters.peRatioMax]}
              onValueChange={([min, max]) => setFilters({ ...filters, peRatioMin: min, peRatioMax: max })}
              min={0}
              max={100}
              step={1}
              className="w-full"
              data-testid="slider-pe-ratio"
            />
            <div className="flex items-center justify-between text-xs text-muted-foreground font-mono">
              <span>{filters.peRatioMin}</span>
              <span>{filters.peRatioMax}</span>
            </div>
          </div>
        </div>

        <Separator />

        <div className="space-y-3">
          <Label className="text-sm font-medium">ROE (%)</Label>
          <div className="space-y-2">
            <Slider
              value={[filters.roeMin, filters.roeMax]}
              onValueChange={([min, max]) => setFilters({ ...filters, roeMin: min, roeMax: max })}
              min={0}
              max={50}
              step={1}
              className="w-full"
              data-testid="slider-roe"
            />
            <div className="flex items-center justify-between text-xs text-muted-foreground font-mono">
              <span>{filters.roeMin}%</span>
              <span>{filters.roeMax}%</span>
            </div>
          </div>
        </div>

        <Separator />

        <div className="space-y-3">
          <Label className="text-sm font-medium">Debt/Equity (Max)</Label>
          <div className="space-y-2">
            <Slider
              value={[filters.debtToEquityMax]}
              onValueChange={([value]) => setFilters({ ...filters, debtToEquityMax: value })}
              min={0}
              max={5}
              step={0.1}
              className="w-full"
              data-testid="slider-debt-equity"
            />
            <div className="text-xs text-muted-foreground font-mono text-right">
              {filters.debtToEquityMax.toFixed(1)}
            </div>
          </div>
        </div>

        <Separator />

        <div className="flex gap-2">
          <Button 
            onClick={handleApply} 
            className="flex-1"
            data-testid="button-apply-filters"
          >
            Apply Filters
          </Button>
          <Button 
            variant="outline" 
            onClick={handleReset}
            data-testid="button-reset-filters"
          >
            Reset
          </Button>
        </div>
      </div>
    </Card>
  );
}
