import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import type { PriceHistory } from "@shared/schema";

interface StockChartProps {
  priceHistory: PriceHistory[];
  stockName: string;
}

type TimePeriod = "1D" | "1W" | "1M" | "3M" | "1Y" | "ALL";

export function StockChart({ priceHistory, stockName }: StockChartProps) {
  const [period, setPeriod] = useState<TimePeriod>("1M");

  const filterDataByPeriod = (data: PriceHistory[], period: TimePeriod) => {
    const now = new Date();
    let cutoffDate = new Date();

    switch (period) {
      case "1D":
        cutoffDate.setDate(now.getDate() - 1);
        break;
      case "1W":
        cutoffDate.setDate(now.getDate() - 7);
        break;
      case "1M":
        cutoffDate.setMonth(now.getMonth() - 1);
        break;
      case "3M":
        cutoffDate.setMonth(now.getMonth() - 3);
        break;
      case "1Y":
        cutoffDate.setFullYear(now.getFullYear() - 1);
        break;
      case "ALL":
        return data;
    }

    return data.filter(d => new Date(d.date) >= cutoffDate);
  };

  const filteredData = filterDataByPeriod(priceHistory, period)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .map(d => ({
      date: new Date(d.date).toLocaleDateString("en-IN", { month: "short", day: "numeric" }),
      price: parseFloat(d.price),
    }));

  const periods: TimePeriod[] = ["1D", "1W", "1M", "3M", "1Y", "ALL"];

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold">Price Chart</h2>
        <div className="flex gap-1">
          {periods.map((p) => (
            <Button
              key={p}
              size="sm"
              variant={period === p ? "default" : "ghost"}
              onClick={() => setPeriod(p)}
              className="h-8"
              data-testid={`button-period-${p}`}
            >
              {p}
            </Button>
          ))}
        </div>
      </div>

      <div className="h-80">
        {filteredData.length > 0 ? (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={filteredData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
              <XAxis 
                dataKey="date" 
                stroke="hsl(var(--muted-foreground))"
                tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                tickFormatter={(value) => `₹${value.toFixed(0)}`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--popover))",
                  border: "1px solid hsl(var(--popover-border))",
                  borderRadius: "6px",
                  color: "hsl(var(--popover-foreground))",
                }}
                labelStyle={{ color: "hsl(var(--popover-foreground))" }}
                formatter={(value: number) => [`₹${value.toFixed(2)}`, "Price"]}
              />
              <Line 
                type="monotone" 
                dataKey="price" 
                stroke="hsl(142 76% 36%)" 
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            No price data available for this period
          </div>
        )}
      </div>
    </Card>
  );
}
