import { useState, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { StockTable } from "@/components/stock-table";
import { SearchBar } from "@/components/search-bar";
import { Navigation } from "@/components/navigation";
import { Button } from "@/components/ui/button";
import type { Stock } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface StocksResponse {
  stocks: Stock[];
  pagination: {
    total: number;
    page: number;
    pageSize: number;
    hasMore: boolean;
  };
}

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [exchange, setExchange] = useState<"" | "NSE" | "BSE">("");
  const { toast } = useToast();

  const queryKey = searchQuery 
    ? ["/api/stocks", { search: searchQuery, page: currentPage }]
    : exchange 
    ? ["/api/stocks", { exchange, page: currentPage }]
    : ["/api/stocks", { page: currentPage }];

  const { data: response, isLoading } = useQuery<StocksResponse>({
    queryKey,
  });

  const stocks = response?.stocks ?? [];
  const pagination = response?.pagination ?? { total: 0, page: 1, pageSize: 50, hasMore: false };

  const { data: watchlistData = [] } = useQuery<{ stockId: string }[]>({
    queryKey: ["/api/watchlist"],
  });

  const watchlistSet = new Set(watchlistData.map(w => w.stockId));

  const addToWatchlistMutation = useMutation({
    mutationFn: (stockId: string) => apiRequest("POST", "/api/watchlist", { stockId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/watchlist"] });
      toast({
        title: "Added to watchlist",
        description: "Stock has been added to your watchlist",
      });
    },
  });

  const removeFromWatchlistMutation = useMutation({
    mutationFn: (stockId: string) => apiRequest("DELETE", `/api/watchlist/${stockId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/watchlist"] });
      toast({
        title: "Removed from watchlist",
        description: "Stock has been removed from your watchlist",
      });
    },
  });

  const handleToggleWatchlist = (stockId: string) => {
    if (watchlistSet.has(stockId)) {
      removeFromWatchlistMutation.mutate(stockId);
    } else {
      addToWatchlistMutation.mutate(stockId);
    }
  };

  const handleNextPage = useCallback(() => {
    if (pagination.hasMore) {
      setCurrentPage(p => p + 1);
    }
  }, [pagination.hasMore]);

  const handlePreviousPage = useCallback(() => {
    if (currentPage > 1) {
      setCurrentPage(p => p - 1);
    }
  }, [currentPage]);

  const handleExchangeChange = (newExchange: "" | "NSE" | "BSE") => {
    setExchange(newExchange);
    setCurrentPage(1);
  };

  const filteredStocks = stocks;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto max-w-7xl px-4 py-4">
          <div className="flex flex-col gap-4">
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="flex items-center gap-2">
                <Search className="h-6 w-6 text-primary" />
                <h1 className="text-2xl font-bold">Stock Screener</h1>
              </div>
              <div className="flex-1 w-full md:w-auto">
                <SearchBar stocks={stocks} onSearch={setSearchQuery} />
              </div>
            </div>
            <Navigation />
          </div>
        </div>
      </header>

      <main className="container mx-auto max-w-7xl px-4 py-8">
        <div className="mb-6">
          <h2 className="text-3xl font-bold mb-2">Indian Stocks (NSE/BSE)</h2>
          <p className="text-muted-foreground">
            Track and analyze top performing stocks from NSE and BSE - {pagination.total} total stocks
          </p>
          <div className="flex gap-2 mt-4">
            <Button 
              variant={exchange === "" ? "default" : "outline"}
              onClick={() => handleExchangeChange("")}
              data-testid="button-exchange-all"
            >
              All
            </Button>
            <Button 
              variant={exchange === "NSE" ? "default" : "outline"}
              onClick={() => handleExchangeChange("NSE")}
              data-testid="button-exchange-nse"
            >
              NSE
            </Button>
            <Button 
              variant={exchange === "BSE" ? "default" : "outline"}
              onClick={() => handleExchangeChange("BSE")}
              data-testid="button-exchange-bse"
            >
              BSE
            </Button>
          </div>
        </div>

        <StockTable 
          stocks={filteredStocks} 
          isLoading={isLoading}
          watchlist={watchlistSet}
          onToggleWatchlist={handleToggleWatchlist}
        />

        <div className="mt-6 flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            Showing {stocks.length > 0 ? (pagination.page - 1) * pagination.pageSize + 1 : 0} to {Math.min(pagination.page * pagination.pageSize, pagination.total)} of {pagination.total} stocks
          </div>
          <div className="flex gap-2">
            <Button 
              onClick={handlePreviousPage} 
              disabled={currentPage === 1}
              variant="outline"
              data-testid="button-prev-page"
            >
              Previous
            </Button>
            <Button 
              variant="outline"
              disabled
              data-testid="text-page-info"
            >
              Page {pagination.page}
            </Button>
            <Button 
              onClick={handleNextPage} 
              disabled={!pagination.hasMore}
              variant="outline"
              data-testid="button-next-page"
            >
              Next
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
