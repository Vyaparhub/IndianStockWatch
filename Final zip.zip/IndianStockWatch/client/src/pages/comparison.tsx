import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { X, Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Navigation } from "@/components/navigation";
import { Card } from "@/components/ui/card";
import type { Stock } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface StocksResponse {
  stocks: Stock[];
  pagination: {
    total: number;
    page: number;
    pageSize: number;
    hasMore: boolean;
  };
}

export default function Comparison() {
  const [selectedStocks, setSelectedStocks] = useState<string[]>([]);
  const [showStockSelector, setShowStockSelector] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  const { data: response } = useQuery<StocksResponse>({
    queryKey: ["/api/stocks", { page: 1, pageSize: 200 }],
  });

  const allStocks = response?.stocks ?? [];

  const filteredStocks = searchQuery
    ? allStocks.filter(
        stock =>
          stock.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
          stock.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : allStocks;

  const selectedStockData = allStocks.filter(stock => selectedStocks.includes(stock.id));

  const handleAddStock = (stockId: string) => {
    if (selectedStocks.includes(stockId)) {
      setSelectedStocks(selectedStocks.filter(id => id !== stockId));
    } else if (selectedStocks.length < 5) {
      setSelectedStocks([...selectedStocks, stockId]);
      toast({
        title: "Stock added",
        description: "Stock added to comparison",
      });
    } else {
      toast({
        title: "Maximum stocks reached",
        description: "You can compare up to 5 stocks",
        variant: "destructive",
      });
    }
  };

  const handleRemoveStock = (stockId: string) => {
    setSelectedStocks(selectedStocks.filter(id => id !== stockId));
  };

  const metrics = [
    { label: "Price", key: "price", format: (v: string) => `₹${parseFloat(v).toFixed(2)}` },
    { label: "Change", key: "change", format: (v: string) => `${parseFloat(v).toFixed(2)}` },
    { label: "Change %", key: "changePercent", format: (v: string) => `${parseFloat(v).toFixed(2)}%` },
    { label: "Volume", key: "volume", format: (v: string) => `${(parseFloat(v) / 1000000).toFixed(2)}M` },
    { label: "Market Cap", key: "marketCap", format: (v: string) => `₹${(parseFloat(v) / 1000000000000).toFixed(2)}T` },
    { label: "P/E Ratio", key: "peRatio", format: (v: string) => parseFloat(v).toFixed(2) },
    { label: "Sector", key: "sector", format: (v: string) => v },
    { label: "Exchange", key: "exchange", format: (v: string) => v },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto max-w-7xl px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">Stock Comparison</h1>
            <span className="text-sm text-muted-foreground">{selectedStocks.length}/5 stocks selected</span>
          </div>
          <Navigation />
        </div>
      </header>

      <main className="container mx-auto max-w-7xl px-4 py-8">
        {selectedStocks.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">Select 2-5 stocks to compare</p>
            <Button onClick={() => setShowStockSelector(!showStockSelector)} data-testid="button-start-comparison">
              <Plus className="w-4 h-4 mr-2" />
              Add Stocks
            </Button>
          </div>
        ) : (
          <>
            <div className="mb-6 flex gap-2 flex-wrap">
              {selectedStockData.map(stock => (
                <div key={stock.id} className="bg-card border border-border rounded-md px-4 py-2 flex items-center gap-2">
                  <span className="font-semibold" data-testid={`text-stock-${stock.symbol}`}>
                    {stock.symbol}
                  </span>
                  <button
                    onClick={() => handleRemoveStock(stock.id)}
                    className="hover:opacity-70"
                    data-testid={`button-remove-${stock.symbol}`}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
              {selectedStocks.length < 5 && (
                <Button
                  variant="outline"
                  onClick={() => setShowStockSelector(!showStockSelector)}
                  size="sm"
                  data-testid="button-add-more"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              )}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold border-b border-border">Metric</th>
                    {selectedStockData.map(stock => (
                      <th
                        key={stock.id}
                        className="text-right py-3 px-4 font-semibold border-b border-border"
                        data-testid={`header-${stock.symbol}`}
                      >
                        {stock.symbol}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {metrics.map(metric => (
                    <tr key={metric.key} className="border-b border-border hover:bg-card/50">
                      <td className="py-3 px-4 font-medium">{metric.label}</td>
                      {selectedStockData.map(stock => (
                        <td
                          key={stock.id}
                          className="text-right py-3 px-4 font-mono text-sm"
                          data-testid={`cell-${stock.symbol}-${metric.key}`}
                        >
                          {metric.format(String(stock[metric.key as keyof Stock] ?? "-"))}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

        {showStockSelector && (
          <div className="mt-8 border-t border-border pt-8">
            <div className="mb-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search stocks..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-border rounded-md bg-background"
                  data-testid="input-search-stocks"
                />
              </div>
            </div>
            <h2 className="text-lg font-semibold mb-4">
              Select Stocks ({filteredStocks.length} available)
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredStocks.map(stock => (
                <button
                  key={stock.id}
                  onClick={() => handleAddStock(stock.id)}
                  className={`p-3 rounded-md border text-left transition-colors ${
                    selectedStocks.includes(stock.id)
                      ? "bg-primary text-primary-foreground border-primary"
                      : "border-border hover:bg-card"
                  }`}
                  data-testid={`button-select-${stock.symbol}`}
                >
                  <div className="font-semibold">{stock.symbol}</div>
                  <div className="text-xs opacity-75">{stock.name}</div>
                  <div className="text-xs font-mono">₹{parseFloat(stock.price).toFixed(2)}</div>
                </button>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
