import { useQuery, useMutation } from "@tanstack/react-query";
import { Star, Search, Trash2, TrendingUp, TrendingDown } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Navigation } from "@/components/navigation";
import type { Stock } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface StocksResponse {
  stocks: Stock[];
  pagination: {
    total: number;
    page: number;
    pageSize: number;
    hasMore: boolean;
  };
}

export default function Watchlist() {
  const { toast } = useToast();

  const { data: watchlistData = [] } = useQuery<{ id: string; stockId: string }[]>({
    queryKey: ["/api/watchlist"],
  });

  const watchlistSet = new Set(watchlistData.map(w => w.stockId));

  const removeFromWatchlistMutation = useMutation({
    mutationFn: (stockId: string) => apiRequest("DELETE", `/api/watchlist/${stockId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/watchlist"] });
      toast({
        title: "Removed from watchlist",
        description: "Stock has been removed from your watchlist",
      });
    },
  });

  const clearWatchlistMutation = useMutation({
    mutationFn: () => apiRequest("DELETE", "/api/watchlist"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/watchlist"] });
      toast({
        title: "Watchlist cleared",
        description: "All stocks have been removed from your watchlist",
      });
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto max-w-7xl px-4 py-4">
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <Star className="h-6 w-6 text-primary fill-primary" />
              <h1 className="text-2xl font-bold">My Watchlist</h1>
            </div>
            <Navigation />
          </div>
        </div>
      </header>

      <main className="container mx-auto max-w-7xl px-4 py-8">
        {watchlistData.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <Star className="h-16 w-16 text-muted-foreground mb-4" />
            <h2 className="text-2xl font-bold mb-2">Your watchlist is empty</h2>
            <p className="text-muted-foreground mb-6 max-w-md">
              Start adding stocks to your watchlist to track your favorite companies
            </p>
            <Link href="/">
              <Button data-testid="button-browse-stocks">
                <Search className="h-4 w-4 mr-2" />
                Browse Stocks
              </Button>
            </Link>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-3xl font-bold mb-2">Your Stocks</h2>
                <p className="text-muted-foreground">
                  {watchlistData.length} stock{watchlistData.length !== 1 ? 's' : ''} in your watchlist
                </p>
              </div>
              <Button
                variant="outline"
                onClick={() => clearWatchlistMutation.mutate()}
                data-testid="button-clear-watchlist"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear All
              </Button>
            </div>

            {/* Watchlist Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold text-sm">Stock ID</th>
                    <th className="text-right py-3 px-4 font-semibold text-sm">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {watchlistData.map((item) => (
                    <tr key={item.id} className="border-b border-border hover:bg-card/50 transition-colors">
                      <td className="py-4 px-4">
                        <Link href={`/stock/${item.stockId}`}>
                          <span className="font-semibold text-sm text-primary hover:underline cursor-pointer" data-testid={`link-stock-${item.stockId}`}>
                            {item.stockId}
                          </span>
                        </Link>
                      </td>
                      <td className="text-right py-4 px-4">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => removeFromWatchlistMutation.mutate(item.stockId)}
                          data-testid={`button-remove-${item.stockId}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
