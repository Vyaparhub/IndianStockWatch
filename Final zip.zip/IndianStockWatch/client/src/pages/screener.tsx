import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Filter } from "lucide-react";
import { StockTable } from "@/components/stock-table";
import { FilterPanel, type FilterValues } from "@/components/filter-panel";
import { Navigation } from "@/components/navigation";
import type { Stock, Financial } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Screener() {
  const [activeFilters, setActiveFilters] = useState<FilterValues>({
    marketCapMin: 0,
    marketCapMax: 1000000,
    peRatioMin: 0,
    peRatioMax: 100,
    roeMin: 0,
    roeMax: 50,
    debtToEquityMax: 5,
  });
  const { toast } = useToast();

  const { data: response, isLoading } = useQuery<any>({
    queryKey: ["/api/stocks"],
  });

  const stocks = response?.stocks ?? [];

  const { data: allFinancials = [] } = useQuery<Financial[]>({
    queryKey: ["/api/financials"],
  });

  const { data: watchlistData = [] } = useQuery<{ stockId: string }[]>({
    queryKey: ["/api/watchlist"],
  });

  const watchlistSet = new Set(watchlistData.map(w => w.stockId));

  const addToWatchlistMutation = useMutation({
    mutationFn: (stockId: string) => apiRequest("POST", "/api/watchlist", { stockId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/watchlist"] });
      toast({
        title: "Added to watchlist",
        description: "Stock has been added to your watchlist",
      });
    },
  });

  const removeFromWatchlistMutation = useMutation({
    mutationFn: (stockId: string) => apiRequest("DELETE", `/api/watchlist/${stockId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/watchlist"] });
      toast({
        title: "Removed from watchlist",
        description: "Stock has been removed from your watchlist",
      });
    },
  });

  const handleToggleWatchlist = (stockId: string) => {
    if (watchlistSet.has(stockId)) {
      removeFromWatchlistMutation.mutate(stockId);
    } else {
      addToWatchlistMutation.mutate(stockId);
    }
  };

  const financialsByStock = allFinancials.reduce((acc, f) => {
    if (!acc[f.stockId]) acc[f.stockId] = [];
    acc[f.stockId].push(f);
    return acc;
  }, {} as Record<string, Financial[]>);

  const filteredStocks = stocks.filter(stock => {
    const marketCap = parseFloat(stock.marketCap);
    const peRatio = stock.peRatio ? parseFloat(stock.peRatio) : null;
    
    if (marketCap < activeFilters.marketCapMin || marketCap > activeFilters.marketCapMax) {
      return false;
    }

    if (peRatio !== null && (peRatio < activeFilters.peRatioMin || peRatio > activeFilters.peRatioMax)) {
      return false;
    }

    const stockFinancials = financialsByStock[stock.id];
    if (stockFinancials && stockFinancials.length > 0) {
      const latestFinancial = stockFinancials.sort((a, b) => b.year - a.year)[0];
      const roe = parseFloat(latestFinancial.roe);
      const debtToEquity = parseFloat(latestFinancial.debtToEquity);

      if (roe < activeFilters.roeMin || roe > activeFilters.roeMax) {
        return false;
      }

      if (debtToEquity > activeFilters.debtToEquityMax) {
        return false;
      }
    }

    return true;
  });

  const defaultFilters: FilterValues = {
    marketCapMin: 0,
    marketCapMax: 1000000,
    peRatioMin: 0,
    peRatioMax: 100,
    roeMin: 0,
    roeMax: 50,
    debtToEquityMax: 5,
  };

  const activeFilterCount = Object.keys(activeFilters).filter(key => {
    const k = key as keyof FilterValues;
    return activeFilters[k] !== defaultFilters[k];
  }).length;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto max-w-7xl px-4 py-4">
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-6 w-6 text-primary" />
              <h1 className="text-2xl font-bold">Stock Screener</h1>
            </div>
            <Navigation />
          </div>
        </div>
      </header>

      <main className="container mx-auto max-w-7xl px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <aside className="lg:col-span-1">
            <FilterPanel 
              onFilterChange={setActiveFilters} 
              activeFilterCount={activeFilterCount}
            />
          </aside>

          <div className="lg:col-span-3">
            <div className="mb-6">
              <h2 className="text-3xl font-bold mb-2">Filtered Stocks</h2>
              <p className="text-muted-foreground">
                {filteredStocks.length} stock{filteredStocks.length !== 1 ? 's' : ''} match your criteria
              </p>
            </div>

            <StockTable 
              stocks={filteredStocks} 
              isLoading={isLoading}
              watchlist={watchlistSet}
              onToggleWatchlist={handleToggleWatchlist}
            />
          </div>
        </div>
      </main>
    </div>
  );
}
