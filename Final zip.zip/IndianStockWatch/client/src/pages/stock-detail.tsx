import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { ArrowLeft, Star, TrendingUp, TrendingDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { StockChart } from "@/components/stock-chart";
import { FinancialMetrics } from "@/components/financial-metrics";
import { QuarterlyResults } from "@/components/quarterly-results";
import type { Stock, Financial, QuarterlyResult, PriceHistory } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function StockDetail() {
  const [, params] = useRoute("/stock/:id");
  const stockId = params?.id;
  const { toast } = useToast();

  const { data: stock, isLoading: isLoadingStock } = useQuery<Stock>({
    queryKey: [`/api/stocks/${stockId}`],
    enabled: !!stockId,
  });

  const { data: financials = [], isLoading: isLoadingFinancials } = useQuery<Financial[]>({
    queryKey: [`/api/stocks/${stockId}/financials`],
    enabled: !!stockId,
  });

  const { data: quarterlyResults = [], isLoading: isLoadingQuarterly } = useQuery<QuarterlyResult[]>({
    queryKey: [`/api/stocks/${stockId}/quarterly`],
    enabled: !!stockId,
  });

  const { data: priceHistory = [], isLoading: isLoadingHistory } = useQuery<PriceHistory[]>({
    queryKey: [`/api/stocks/${stockId}/history`],
    enabled: !!stockId,
  });

  const { data: watchlistData = [] } = useQuery<{ stockId: string }[]>({
    queryKey: ["/api/watchlist"],
  });

  const isInWatchlist = watchlistData.some(w => w.stockId === stockId);

  const addToWatchlistMutation = useMutation({
    mutationFn: (stockId: string) => apiRequest("POST", "/api/watchlist", { stockId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/watchlist"] });
      toast({
        title: "Added to watchlist",
        description: "Stock has been added to your watchlist",
      });
    },
  });

  const removeFromWatchlistMutation = useMutation({
    mutationFn: (stockId: string) => apiRequest("DELETE", `/api/watchlist/${stockId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/watchlist"] });
      toast({
        title: "Removed from watchlist",
        description: "Stock has been removed from your watchlist",
      });
    },
  });

  const handleToggleWatchlist = () => {
    if (!stockId) return;
    if (isInWatchlist) {
      removeFromWatchlistMutation.mutate(stockId);
    } else {
      addToWatchlistMutation.mutate(stockId);
    }
  };

  if (isLoadingStock) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="h-8 w-32 mb-8" />
          <Skeleton className="h-32 w-full mb-8" />
          <Skeleton className="h-96 w-full mb-8" />
        </div>
      </div>
    );
  }

  if (!stock) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <Link href="/">
            <Button variant="ghost" className="mb-8">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <div className="text-center py-16">
            <h2 className="text-2xl font-bold mb-2">Stock not found</h2>
            <p className="text-muted-foreground">The stock you're looking for doesn't exist</p>
          </div>
        </div>
      </div>
    );
  }

  const change = parseFloat(stock.change);
  const changePercent = parseFloat(stock.changePercent);
  const isPositive = change >= 0;

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto max-w-7xl px-4 py-8">
        <Link href="/">
          <Button variant="ghost" className="mb-8" data-testid="button-back">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
        </Link>

        <Card className="p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-3xl font-bold" data-testid="text-stock-name">{stock.name}</h1>
                <Badge variant="outline" data-testid="text-stock-symbol">
                  <code>{stock.symbol}</code>
                </Badge>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span>{stock.exchange}</span>
                <span>•</span>
                <span>{stock.sector}</span>
              </div>
            </div>
            <Button
              variant={isInWatchlist ? "default" : "outline"}
              onClick={handleToggleWatchlist}
              data-testid="button-toggle-watchlist"
            >
              <Star className={`h-4 w-4 mr-2 ${isInWatchlist ? 'fill-current' : ''}`} />
              {isInWatchlist ? "In Watchlist" : "Add to Watchlist"}
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="text-sm text-muted-foreground mb-1">Current Price</div>
              <div className="text-3xl font-bold font-mono" data-testid="text-current-price">
                ₹{parseFloat(stock.price).toFixed(2)}
              </div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground mb-1">Change</div>
              <div className={`text-2xl font-semibold font-mono flex items-center gap-2 ${isPositive ? 'text-positive' : 'text-negative'}`} data-testid="text-change">
                {isPositive ? <TrendingUp className="h-5 w-5" /> : <TrendingDown className="h-5 w-5" />}
                {isPositive ? '+' : ''}{change.toFixed(2)} ({isPositive ? '+' : ''}{changePercent.toFixed(2)}%)
              </div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground mb-1">Market Cap</div>
              <div className="text-2xl font-semibold font-mono" data-testid="text-market-cap">
                {(() => {
                  const cap = parseFloat(stock.marketCap);
                  if (cap >= 1000000000000) {
                    return `₹${(cap / 1000000000000).toFixed(2)}T`;
                  } else if (cap >= 100000000000) {
                    return `₹${(cap / 100000000).toFixed(2)}K Cr`;
                  } else if (cap >= 10000000) {
                    return `₹${(cap / 10000000).toFixed(2)}Cr`;
                  }
                  return `₹${cap.toFixed(2)}`;
                })()}
              </div>
            </div>
          </div>
        </Card>

        <div className="space-y-8">
          {isLoadingHistory ? (
            <Skeleton className="h-96 w-full" />
          ) : (
            <StockChart priceHistory={priceHistory} stockName={stock.name} />
          )}

          {isLoadingFinancials ? (
            <Skeleton className="h-64 w-full" />
          ) : (
            <FinancialMetrics financials={financials} />
          )}

          {isLoadingQuarterly ? (
            <Skeleton className="h-96 w-full" />
          ) : (
            <QuarterlyResults results={quarterlyResults} />
          )}
        </div>
      </div>
    </div>
  );
}
