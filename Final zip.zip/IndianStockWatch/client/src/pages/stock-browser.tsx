import { useState, useRef, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { ChevronDown, ChevronUp, TrendingUp, TrendingDown, Filter, Search, X, ArrowUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import type { Stock } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface StocksResponse {
  stocks: Stock[];
  pagination: {
    total: number;
    page: number;
    pageSize: number;
    hasMore: boolean;
  };
}

export default function StockBrowser() {
  const [, navigate] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState<string | null>("ALL");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedStocks, setSelectedStocks] = useState<string[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [allLoadedStocks, setAllLoadedStocks] = useState<Stock[]>([]);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const tableContainerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const { data: indices = [] } = useQuery({
    queryKey: ["/api/indices"],
  });

  // Fetch 50 stocks per page
  const { data: response, isLoading } = useQuery<StocksResponse>({
    queryKey: ["/api/stocks", { page: currentPage, pageSize: 50, index: selectedIndex }],
  });

  const stocks = response?.stocks ?? [];
  const pagination = response?.pagination ?? { total: 0, page: 1, pageSize: 50, hasMore: false };
  const totalPages = Math.ceil(pagination.total / pagination.pageSize);

  // Accumulate stocks for infinite scroll
  useEffect(() => {
    if (stocks.length > 0) {
      if (currentPage === 1) {
        setAllLoadedStocks(stocks);
      } else {
        setAllLoadedStocks(prev => [...prev, ...stocks]);
      }
    }
  }, [stocks, currentPage]);

  // Filter stocks based on search query
  const filteredStocks = searchQuery
    ? allLoadedStocks.filter(stock =>
        stock.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
        stock.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        stock.sector.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : allLoadedStocks;

  const handleIndexSelect = (indexId: string) => {
    setSelectedIndex(indexId);
    setCurrentPage(1);
    setAllLoadedStocks([]);
    setSidebarOpen(false);
    setSelectedStocks([]);
    setSelectAll(false);
    setSearchQuery("");
  };

  const handleLoadMore = () => {
    if (currentPage < totalPages) {
      setCurrentPage(prev => prev + 1);
    }
  };

  const handleSelectAll = (checked: boolean) => {
    setSelectAll(checked);
    setSelectedStocks(checked ? filteredStocks.map(s => s.symbol) : []);
  };

  const handleSelectStock = (symbol: string, checked: boolean) => {
    if (checked) {
      setSelectedStocks(prev => [...prev, symbol]);
    } else {
      setSelectedStocks(prev => prev.filter(s => s !== symbol));
    }
  };

  const handleCompare = () => {
    navigate(`/comparison?symbols=${selectedStocks.join(",")}`);
  };

  const handleScroll = () => {
    if (tableContainerRef.current) {
      setShowScrollTop(tableContainerRef.current.scrollTop > 200);
    }
  };

  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTop = 0;
    }
  };

  const clearSearch = () => {
    setSearchQuery("");
  };

  const handleResetFilters = () => {
    setSelectedIndex("ALL");
    setCurrentPage(1);
    setAllLoadedStocks([]);
    setSelectedStocks([]);
    setSelectAll(false);
    setSearchQuery("");
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-card px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-bold">Stock Screener</h1>
          <div className="text-sm text-secondary-foreground">
            Real-time NSE/BSE Market Data
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 p-4">
          {/* Sidebar */}
          {(sidebarOpen || window.innerWidth >= 1024) && (
            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <div className="p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold flex items-center gap-2">
                      <Filter className="w-4 h-4" />
                      Indices
                    </h3>
                    <button
                      onClick={() => setSidebarOpen(false)}
                      className="lg:hidden"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-2">
                    {[
                      { id: "ALL", name: "All Stocks" },
                      ...indices
                    ].map((index: any) => (
                      <button
                        key={index.id}
                        onClick={() => handleIndexSelect(index.id)}
                        className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                          selectedIndex === index.id
                            ? "bg-primary text-primary-foreground"
                            : "hover:bg-accent"
                        }`}
                        data-testid={`button-index-${index.id}`}
                      >
                        {index.name}
                      </button>
                    ))}
                  </div>
                </div>
              </Card>
            </div>
          )}

          {/* Main Content */}
          <div className={sidebarOpen ? "lg:col-span-3" : "col-span-1 lg:col-span-4"}>
            {isLoading && currentPage === 1 ? (
              <div className="flex justify-center py-12">
                <div className="text-muted-foreground">Loading stocks...</div>
              </div>
            ) : (
              <>
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold">
                      {selectedIndex === "ALL"
                        ? "All Stocks"
                        : indices.find((i: any) => i.id === selectedIndex)?.name}
                    </h2>
                    {selectedStocks.length > 0 && (
                      <Button
                        onClick={handleCompare}
                        data-testid="button-compare-selected"
                        className="gap-2"
                      >
                        Compare Selected ({selectedStocks.length})
                      </Button>
                    )}
                  </div>

                  {/* Search Bar */}
                  <div className="relative mb-4">
                    <div className="flex gap-2 items-center bg-card border border-border rounded-lg p-2">
                      <Search className="w-4 h-4 text-muted-foreground ml-2" />
                      <input
                        type="text"
                        placeholder="Search by company name, symbol, or sector..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        data-testid="input-search"
                        className="flex-1 bg-transparent outline-none text-sm"
                      />
                      {searchQuery && (
                        <button
                          onClick={clearSearch}
                          className="p-1 hover:bg-accent rounded"
                          data-testid="button-clear-search"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground">
                    Showing {filteredStocks.length} of {pagination.total} stocks
                    {selectedStocks.length > 0 && ` • ${selectedStocks.length} selected`}
                  </p>
                </div>

                {/* Scrollable Stocks Table */}
                <div className="overflow-y-auto mb-6 relative" ref={tableContainerRef} style={{ maxHeight: "600px" }} onScroll={handleScroll}>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="sticky top-0 bg-card">
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-4 font-semibold text-sm w-12">
                            <Checkbox
                              checked={selectAll && filteredStocks.length > 0}
                              onCheckedChange={handleSelectAll}
                              data-testid="checkbox-select-all"
                            />
                          </th>
                          <th className="text-left py-3 px-4 font-semibold text-sm">Symbol</th>
                          <th className="text-left py-3 px-4 font-semibold text-sm">Company</th>
                          <th className="text-right py-3 px-4 font-semibold text-sm">Price</th>
                          <th className="text-right py-3 px-4 font-semibold text-sm">Change</th>
                          <th className="text-right py-3 px-4 font-semibold text-sm">Volume</th>
                          <th className="text-right py-3 px-4 font-semibold text-sm">Market Cap</th>
                          <th className="text-left py-3 px-4 font-semibold text-sm">Sector</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredStocks.map((stock) => {
                          const changePercent = parseFloat(stock.changePercent.toString());
                          const isPositive = changePercent >= 0;
                          return (
                            <tr key={stock.symbol} className="border-b border-border hover:bg-card/50 transition-colors cursor-pointer" onClick={() => navigate(`/stock/${stock.symbol}`)}>
                              <td className="py-4 px-4" onClick={(e) => e.stopPropagation()}>
                                <Checkbox
                                  checked={selectedStocks.includes(stock.symbol)}
                                  onCheckedChange={(checked) => handleSelectStock(stock.symbol, checked as boolean)}
                                  data-testid={`checkbox-stock-${stock.symbol}`}
                                />
                              </td>
                              <td className="py-4 px-4 font-medium text-sm" data-testid={`symbol-${stock.symbol}`}>
                                {stock.symbol}
                              </td>
                              <td className="py-4 px-4 text-sm" data-testid={`name-${stock.symbol}`}>
                                {stock.name}
                              </td>
                              <td className="text-right py-4 px-4 font-medium" data-testid={`price-${stock.symbol}`}>
                                ₹{parseFloat(stock.price.toString()).toFixed(2)}
                              </td>
                              <td className={`text-right py-4 px-4 font-medium flex items-center justify-end gap-1 ${
                                isPositive ? "text-green-600" : "text-red-600"
                              }`} data-testid={`change-${stock.symbol}`}>
                                {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                                {isPositive ? "+" : ""}{changePercent.toFixed(2)}%
                              </td>
                              <td className="text-right py-4 px-4 text-sm" data-testid={`volume-${stock.symbol}`}>
                                {Math.round(parseFloat(stock.volume.toString()) / 1000000)}M
                              </td>
                              <td className="text-right py-4 px-4 text-sm" data-testid={`marketcap-${stock.symbol}`}>
                                {formatMarketCap(parseFloat(stock.marketCap.toString()))}
                              </td>
                              <td className="py-4 px-4 text-sm" data-testid={`sector-${stock.symbol}`}>
                                {stock.sector}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {showScrollTop && (
                  <button
                    onClick={scrollToTop}
                    className="fixed bottom-8 right-8 p-3 bg-primary text-primary-foreground rounded-full shadow-lg hover:opacity-90 z-40 transition-opacity"
                    data-testid="button-scroll-top"
                    title="Back to top"
                  >
                    <ArrowUp className="w-5 h-5" />
                  </button>
                )}

                {/* Load More & Reset Buttons */}
                {filteredStocks.length > 0 && (
                  <div className="flex justify-center gap-4">
                    {currentPage < totalPages && !searchQuery && (
                      <Button
                        onClick={handleLoadMore}
                        variant="outline"
                        disabled={isLoading}
                        data-testid="button-load-more"
                      >
                        {isLoading ? "Loading..." : "Load More"}
                      </Button>
                    )}
                    {(searchQuery || selectedIndex !== "ALL" || currentPage > 1 || selectedStocks.length > 0) && (
                      <Button
                        onClick={handleResetFilters}
                        variant="outline"
                        data-testid="button-reset"
                      >
                        Reset Filters
                      </Button>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        {!sidebarOpen && window.innerWidth < 1024 && (
          <div className="fixed bottom-6 right-6">
            <Button
              onClick={() => setSidebarOpen(true)}
              size="icon"
              data-testid="button-toggle-filters"
            >
              <Filter className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

function formatMarketCap(marketCap: number): string {
  if (marketCap >= 100000000000000) {
    return `₹${(marketCap / 1000000000000).toFixed(2)}T`;
  } else if (marketCap >= 10000000000) {
    return `₹${(marketCap / 1000000000).toFixed(2)}Cr`;
  } else if (marketCap >= 1000000) {
    return `₹${(marketCap / 1000000).toFixed(2)}Cr`;
  }
  return `₹${marketCap.toFixed(2)}`;
}
