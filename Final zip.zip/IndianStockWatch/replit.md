# Stock Screener Application

## Overview

This is a stock screener web application designed to help users analyze and track Indian stock market data. The application provides comprehensive financial information, filtering capabilities, and watchlist management for stocks traded on the NSE (National Stock Exchange). It follows a professional, data-first design approach inspired by screener.in, prioritizing information density and readability over decorative elements.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- **Framework:** React 18 with TypeScript
- **Routing:** Wouter (lightweight client-side routing)
- **State Management:** TanStack React Query v5 for server state management
- **Styling:** Tailwind CSS with custom design system
- **UI Components:** Shadcn/ui (Radix UI primitives with custom styling)
- **Build Tool:** Vite

**Design System:**
- Custom color palette supporting light/dark themes with CSS variables
- Typography hierarchy optimized for financial data (monospace fonts for numbers)
- Comprehensive component library from Shadcn/ui (30+ components)
- Professional financial interface following the guidelines in `design_guidelines.md`

**Key Pages:**
1. **Home** - Stock listing with search functionality
2. **Stock Detail** - Comprehensive view with price history, financials, and quarterly results
3. **Screener** - Advanced filtering based on financial metrics (P/E ratio, ROE, market cap, etc.)
4. **Watchlist** - User's tracked stocks

**State Management Strategy:**
- Server state cached via React Query with infinite stale time
- Optimistic updates for watchlist operations
- Query invalidation pattern for data consistency

### Backend Architecture

**Technology Stack:**
- **Runtime:** Node.js with TypeScript
- **Framework:** Express.js
- **ORM:** Drizzle ORM
- **Database Driver:** Neon Serverless (PostgreSQL)
- **Session Management:** Connect-pg-simple with PostgreSQL

**API Structure:**
- RESTful API design with `/api` prefix
- Resource-based endpoints for stocks, financials, quarterly results, and watchlist
- Standard CRUD operations with proper error handling

**Key Endpoints:**
- `GET /api/stocks` - List all stocks
- `GET /api/stocks/:id` - Individual stock details
- `GET /api/stocks/:id/financials` - Annual financial data
- `GET /api/stocks/:id/quarterly` - Quarterly results
- `GET /api/stocks/:id/history` - Price history
- `GET /api/watchlist` - User's watchlist
- `POST /api/watchlist` - Add to watchlist
- `DELETE /api/watchlist/:stockId` - Remove from watchlist
- `DELETE /api/watchlist` - Clear entire watchlist

**Development vs Production:**
- Separate entry points (`index-dev.ts` and `index-prod.ts`)
- Development: Vite middleware integration with HMR
- Production: Static file serving from `dist/public`

### Data Storage

**Database Schema (PostgreSQL via Drizzle ORM):**

1. **stocks** table:
   - Core stock information (name, symbol, price, volume, market cap, P/E ratio)
   - Sector and exchange classification
   - Decimal precision for financial values

2. **financials** table:
   - Annual financial metrics (revenue, profit, EPS, ROE, debt-to-equity)
   - Foreign key relationship to stocks with cascade delete
   - Year-based tracking

3. **quarterlyResults** table:
   - Quarterly performance data (revenue, profit, EPS)
   - Quarter and year tracking
   - Foreign key to stocks

4. **watchlist** table:
   - User's saved stocks with timestamps
   - Unique constraint on stockId
   - Foreign key with cascade delete

5. **priceHistory** table:
   - Historical price data with timestamps
   - Supports charting and trend analysis

**Data Validation:**
- Zod schemas derived from Drizzle tables via `drizzle-zod`
- Type-safe insert/update operations

### External Dependencies

**Database:**
- **Neon Serverless PostgreSQL** - Managed database with WebSocket support
- Connection pooling via `@neondatabase/serverless`
- Environment variable: `DATABASE_URL`

**Development Tools:**
- Replit-specific plugins for development experience (cartographer, dev banner, runtime error overlay)
- Google Fonts CDN for typography (Inter, Work Sans, JetBrains Mono)

**UI Component Library:**
- Radix UI primitives (30+ packages for accessible components)
- Recharts for data visualization
- Lucide React for icons
- cmdk for command palette functionality
- embla-carousel-react for carousels

**Form Handling:**
- React Hook Form with Hookform resolvers
- Zod for validation schemas

**Utilities:**
- date-fns for date manipulation
- class-variance-authority (CVA) for component variants
- clsx and tailwind-merge for conditional styling

**Session Storage:**
- connect-pg-simple for PostgreSQL-backed sessions
- Express session middleware integration