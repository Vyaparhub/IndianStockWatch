# Stock Screener Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from screener.in's professional financial interface, combined with modern data-visualization principles. This is a utility-focused application where clarity, scannability, and efficiency are paramount.

## Core Design Principles
1. **Data-First Design**: Information hierarchy prioritizes numerical data and financial metrics
2. **Professional Restraint**: Minimal decorative elements; focus on readability and speed
3. **Consistent Visual Language**: Establish clear patterns for positive/negative values and data states

## Typography System
- **Primary Font**: Inter or Work Sans (Google Fonts CDN) - excellent for tabular data
- **Monospace**: JetBrains Mono for numerical values and stock symbols
- **Hierarchy**:
  - Page Titles: text-2xl md:text-3xl font-bold
  - Section Headers: text-xl font-semibold
  - Stock Prices/Primary Data: text-lg md:text-xl font-semibold (monospace)
  - Table Headers: text-sm font-medium uppercase tracking-wide
  - Body Text: text-sm md:text-base
  - Secondary Info: text-xs md:text-sm

## Layout System
**Spacing Primitives**: Use Tailwind units of 2, 4, 6, and 8 for consistency
- Component padding: p-4 to p-6
- Section spacing: py-8 to py-12
- Card gaps: gap-4 to gap-6
- Table cell padding: px-4 py-3

**Container Strategy**:
- Full-width layout with max-w-7xl container
- No hero sections - immediate access to stock data
- Dense information display optimized for desktop (responsive breakdowns for mobile)

## Component Library

### Navigation
- Top navigation bar with logo, search bar, and main navigation links (Home, Screener, Watchlist)
- Sticky header for persistent access
- Search bar prominent and centered (takes 40-50% of header width on desktop)
- Icons: Heroicons via CDN

### Stock Table (Homepage & Screener)
- 8-column grid on desktop: Stock Name | Symbol | Price | Change | % Change | Volume | Market Cap | P/E
- Responsive: Stack to 4 columns on tablet, card-based view on mobile
- Alternating row treatment for scannability
- Hover state: subtle highlight on entire row
- Sortable columns with clear sort indicators
- Fixed header on scroll
- Monospace font for all numerical columns
- Right-align numerical data

### Stock Cards (Mobile View)
- Compact card layout when table breaks down
- Stock name/symbol as header
- Grid display of key metrics below
- Tap entire card to navigate to detail page

### Stock Detail Page
- **Header Section**: Stock name, symbol, current price (large), change indicators
- **Price Chart**: Full-width chart section (use Chart.js or Recharts)
- **Financial Metrics Grid**: 2x2 or 3x2 grid for Revenue, Profit, EPS, ROE
- **Quarterly Results**: Horizontal scrollable table or accordion for multiple quarters
- Each metric in its own card with label, value, and context

### Screener Filters
- Left sidebar (desktop) or collapsible panel (mobile)
- Filter categories grouped: Market Cap, Valuation (P/E), Performance (ROE), Financial Health (Debt/Equity)
- Range sliders for numerical filters
- Clear "Apply Filters" and "Reset" buttons
- Active filter count badge

### Watchlist
- Compact list view similar to main stock table
- Quick-remove action (trash icon)
- Empty state with illustration and prompt to add stocks
- Drag-to-reorder capability (visual affordance: drag handle icon)

### Search Functionality
- Real-time search with dropdown suggestions
- Display: Stock Name + Symbol in results
- Keyboard navigation support (arrow keys, enter to select)
- Recent searches section

## Data Visualization

### Financial Value Display
- Positive values: Use provided green treatment
- Negative values: Use provided red treatment  
- Neutral values: Standard text treatment
- Change indicators: Arrow icons (↑↓) preceding percentage values
- Large numbers: Format with abbreviations (₹1.2Cr, ₹450L)

### Charts
- Line chart for price history (use Recharts or Chart.js)
- Minimal gridlines, clear axis labels
- Tooltip on hover with precise values
- Time period selector: 1D, 1W, 1M, 3M, 1Y, ALL

### Status Indicators
- Loading states: Skeleton screens for tables and cards
- Empty states: Centered message with icon
- Error states: Clear error message with retry action

## Interaction Patterns

### Buttons
- Primary CTA: Solid button with subtle shadow
- Secondary: Outline button
- Icon buttons: Square with centered icon
- Size variants: sm (filter tags), md (standard), lg (primary actions)

### Forms
- Input fields with clear labels above
- Focus states with border highlight
- Helper text below inputs when needed
- Validation: Inline error messages

### Tables
- Row hover: Entire row clickable/hoverable
- Click row to navigate to stock detail
- Star icon in first column for watchlist add/remove

## Responsive Breakpoints
- Mobile (base): Single column, stacked cards
- Tablet (md: 768px): 2-column grids, condensed table
- Desktop (lg: 1024px): Full 8-column table, sidebar filters
- Wide (xl: 1280px): Optimal viewing, max-w-7xl container

## Performance Considerations
- Virtualized scrolling for large stock lists (100+ items)
- Lazy load chart components
- Debounced search input
- Optimistic UI updates for watchlist actions

## Accessibility
- Semantic HTML throughout (table, thead, tbody for data tables)
- ARIA labels for icon-only buttons
- Keyboard navigation for all interactive elements
- Focus visible indicators
- Screen reader announcements for data updates

## Images
**No hero images or decorative imagery required.** This is a data-centric application where content is the visual centerpiece. Stock logos may be displayed as small icons (24x24px) next to stock names if available.