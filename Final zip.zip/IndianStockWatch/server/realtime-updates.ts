// Real-time stock price updates service
// Simulates live price updates by randomly adjusting stock prices

interface RealTimePrice {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
}

class RealTimeUpdatesService {
  private prices: Map<string, RealTimePrice> = new Map();
  private updateInterval: NodeJS.Timer | null = null;

  initializePrices(stocks: any[]): void {
    stocks.forEach(stock => {
      this.prices.set(stock.symbol, {
        symbol: stock.symbol,
        price: parseFloat(stock.price),
        change: parseFloat(stock.change),
        changePercent: parseFloat(stock.changePercent),
        volume: parseFloat(stock.volume),
      });
    });
  }

  startPriceUpdates(updateIntervalMs: number = 3000): void {
    if (this.updateInterval) clearInterval(this.updateInterval);

    this.updateInterval = setInterval(() => {
      this.prices.forEach((price, symbol) => {
        const volatility = 0.02; // 2% volatility
        const change = (Math.random() - 0.5) * volatility * price.price;
        const newPrice = Math.max(price.price + change, 0.01);
        const percentChange = ((newPrice - price.price) / price.price) * 100;

        this.prices.set(symbol, {
          symbol,
          price: newPrice,
          change: change,
          changePercent: percentChange,
          volume: price.volume + Math.floor(Math.random() * 50000),
        });
      });
    }, updateIntervalMs);
  }

  stopPriceUpdates(): void {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
  }

  getPrices(): Map<string, RealTimePrice> {
    return this.prices;
  }

  getPrice(symbol: string): RealTimePrice | undefined {
    return this.prices.get(symbol);
  }
}

export const realtimeUpdates = new RealTimeUpdatesService();
