import { storage } from "./storage";
import type {
  InsertStock,
  InsertFinancial,
  InsertQuarterlyResult,
  InsertPriceHistory,
} from "@shared/schema";

const indianStocks: InsertStock[] = [
  {
    name: "Reliance Industries",
    symbol: "RELIANCE",
    price: "2456.75",
    change: "42.30",
    changePercent: "1.75",
    volume: "45678900",
    marketCap: "1665432.50",
    peRatio: "28.45",
    sector: "Conglomerate",
    exchange: "NSE",
  },
  {
    name: "Tata Consultancy Services",
    symbol: "TCS",
    price: "3542.80",
    change: "-18.45",
    changePercent: "-0.52",
    volume: "32456780",
    marketCap: "1294567.80",
    peRatio: "31.20",
    sector: "IT Services",
    exchange: "NSE",
  },
  {
    name: "Infosys",
    symbol: "INFY",
    price: "1567.90",
    change: "23.60",
    changePercent: "1.53",
    volume: "56789000",
    marketCap: "652341.20",
    peRatio: "27.85",
    sector: "IT Services",
    exchange: "NSE",
  },
  {
    name: "HDFC Bank",
    symbol: "HDFCBANK",
    price: "1654.35",
    change: "12.80",
    changePercent: "0.78",
    volume: "78901234",
    marketCap: "912345.60",
    peRatio: "19.75",
    sector: "Banking",
    exchange: "NSE",
  },
  {
    name: "ICICI Bank",
    symbol: "ICICIBANK",
    price: "987.45",
    change: "-5.60",
    changePercent: "-0.56",
    volume: "67890123",
    marketCap: "692456.30",
    peRatio: "18.92",
    sector: "Banking",
    exchange: "NSE",
  },
  {
    name: "Wipro",
    symbol: "WIPRO",
    price: "432.60",
    change: "8.75",
    changePercent: "2.07",
    volume: "43210987",
    marketCap: "236789.40",
    peRatio: "22.15",
    sector: "IT Services",
    exchange: "NSE",
  },
  {
    name: "Bharti Airtel",
    symbol: "BHARTIARTL",
    price: "1234.50",
    change: "34.20",
    changePercent: "2.85",
    volume: "34567890",
    marketCap: "678901.20",
    peRatio: "45.60",
    sector: "Telecom",
    exchange: "NSE",
  },
  {
    name: "State Bank of India",
    symbol: "SBIN",
    price: "623.75",
    change: "-7.35",
    changePercent: "-1.16",
    volume: "89012345",
    marketCap: "556789.50",
    peRatio: "12.35",
    sector: "Banking",
    exchange: "NSE",
  },
  {
    name: "ITC",
    symbol: "ITC",
    price: "456.90",
    change: "3.45",
    changePercent: "0.76",
    volume: "54321098",
    marketCap: "567890.30",
    peRatio: "26.80",
    sector: "FMCG",
    exchange: "NSE",
  },
  {
    name: "Larsen & Toubro",
    symbol: "LT",
    price: "3234.60",
    change: "67.80",
    changePercent: "2.14",
    volume: "23456789",
    marketCap: "453456.70",
    peRatio: "34.25",
    sector: "Infrastructure",
    exchange: "NSE",
  },
];

export async function seedDatabase() {
  try {
    console.log("Starting database seeding...");

    const createdStocks = [];
    for (const stockData of indianStocks) {
      const stock = await storage.createStock(stockData);
      createdStocks.push(stock);
      console.log(`Created stock: ${stock.name}`);
    }

    for (const stock of createdStocks) {
      const financialData: InsertFinancial = {
        stockId: stock.id,
        revenue: (Math.random() * 100000 + 50000).toFixed(2),
        profit: (Math.random() * 20000 + 5000).toFixed(2),
        eps: (Math.random() * 50 + 10).toFixed(2),
        roe: (Math.random() * 30 + 10).toFixed(2),
        debtToEquity: (Math.random() * 2 + 0.2).toFixed(2),
        year: 2024,
      };
      await storage.createFinancial(financialData);

      const prevYearFinancial: InsertFinancial = {
        stockId: stock.id,
        revenue: (parseFloat(financialData.revenue) * 0.9).toFixed(2),
        profit: (parseFloat(financialData.profit) * 0.85).toFixed(2),
        eps: (parseFloat(financialData.eps) * 0.88).toFixed(2),
        roe: (parseFloat(financialData.roe) * 0.92).toFixed(2),
        debtToEquity: (parseFloat(financialData.debtToEquity) * 1.1).toFixed(2),
        year: 2023,
      };
      await storage.createFinancial(prevYearFinancial);

      console.log(`Created financials for: ${stock.name}`);
    }

    for (const stock of createdStocks) {
      const quarters = ["Q1", "Q2", "Q3", "Q4"];
      for (const quarter of quarters) {
        const quarterlyData: InsertQuarterlyResult = {
          stockId: stock.id,
          quarter,
          year: 2024,
          revenue: (Math.random() * 25000 + 10000).toFixed(2),
          profit: (Math.random() * 5000 + 1000).toFixed(2),
          eps: (Math.random() * 15 + 3).toFixed(2),
        };
        await storage.createQuarterlyResult(quarterlyData);
      }

      for (const quarter of quarters.slice(0, 2)) {
        const quarterlyData: InsertQuarterlyResult = {
          stockId: stock.id,
          quarter,
          year: 2023,
          revenue: (Math.random() * 23000 + 9000).toFixed(2),
          profit: (Math.random() * 4500 + 900).toFixed(2),
          eps: (Math.random() * 13 + 2.5).toFixed(2),
        };
        await storage.createQuarterlyResult(quarterlyData);
      }

      console.log(`Created quarterly results for: ${stock.name}`);
    }

    for (const stock of createdStocks) {
      const basePrice = parseFloat(stock.price);
      const days = 90;

      for (let i = days; i >= 0; i -= 2) {
        const date = new Date();
        date.setDate(date.getDate() - i);

        const volatility = 0.02;
        const trend = -0.0001;
        const randomChange = (Math.random() - 0.5) * 2 * volatility;
        const priceChange = basePrice * (trend + randomChange);
        const dayPrice = Math.max(basePrice + priceChange * i, basePrice * 0.7);

        const priceData: InsertPriceHistory = {
          stockId: stock.id,
          date: date,
          price: dayPrice.toFixed(2),
        };
        await storage.createPriceHistory(priceData);
      }

      console.log(`Created price history for: ${stock.name}`);
    }

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}
