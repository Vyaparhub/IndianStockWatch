import { 
  users,
  stocks, 
  financials, 
  quarterlyResults, 
  watchlist,
  priceHistory,
  type User,
  type InsertUser,
  type Stock, 
  type InsertStock,
  type Financial,
  type InsertFinancial,
  type QuarterlyResult,
  type InsertQuarterlyResult,
  type Watchlist,
  type InsertWatchlist,
  type PriceHistory,
  type InsertPriceHistory
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, sql } from "drizzle-orm";

export interface IStorage {
  getUser(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getStocks(): Promise<Stock[]>;
  getStock(id: string): Promise<Stock | undefined>;
  createStock(stock: InsertStock): Promise<Stock>;
  
  getFinancials(stockId: string): Promise<Financial[]>;
  getAllFinancials(): Promise<Financial[]>;
  createFinancial(financial: InsertFinancial): Promise<Financial>;
  
  getQuarterlyResults(stockId: string): Promise<QuarterlyResult[]>;
  createQuarterlyResult(result: InsertQuarterlyResult): Promise<QuarterlyResult>;
  
  getWatchlist(userId: string): Promise<Watchlist[]>;
  addToWatchlist(userId: string, stockId: string): Promise<Watchlist>;
  removeFromWatchlist(userId: string, stockId: string): Promise<void>;
  clearWatchlist(userId: string): Promise<void>;
  
  getPriceHistory(stockId: string): Promise<PriceHistory[]>;
  createPriceHistory(history: InsertPriceHistory): Promise<PriceHistory>;
}

export class MemStorage implements IStorage {
  private users: User[] = [];
  private stocks: Stock[] = [];
  private financials: Financial[] = [];
  private quarterlyResults: QuarterlyResult[] = [];
  private watchlist: Watchlist[] = [];
  private priceHistory: PriceHistory[] = [];

  async getUser(email: string): Promise<User | undefined> {
    return this.users.find(u => u.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      id: crypto.randomUUID(),
      ...insertUser,
      createdAt: new Date(),
    };
    this.users.push(user);
    return user;
  }

  async getStocks(): Promise<Stock[]> {
    return this.stocks;
  }

  async getStock(id: string): Promise<Stock | undefined> {
    return this.stocks.find(s => s.id === id);
  }

  async createStock(insertStock: InsertStock): Promise<Stock> {
    const stock: Stock = {
      id: crypto.randomUUID(),
      ...insertStock,
    };
    this.stocks.push(stock);
    return stock;
  }

  async getFinancials(stockId: string): Promise<Financial[]> {
    return this.financials.filter(f => f.stockId === stockId);
  }

  async getAllFinancials(): Promise<Financial[]> {
    return this.financials;
  }

  async createFinancial(insertFinancial: InsertFinancial): Promise<Financial> {
    const financial: Financial = {
      id: crypto.randomUUID(),
      ...insertFinancial,
    };
    this.financials.push(financial);
    return financial;
  }

  async getQuarterlyResults(stockId: string): Promise<QuarterlyResult[]> {
    return this.quarterlyResults.filter(qr => qr.stockId === stockId);
  }

  async createQuarterlyResult(insertResult: InsertQuarterlyResult): Promise<QuarterlyResult> {
    const result: QuarterlyResult = {
      id: crypto.randomUUID(),
      ...insertResult,
    };
    this.quarterlyResults.push(result);
    return result;
  }

  async getWatchlist(userId: string): Promise<Watchlist[]> {
    return this.watchlist.filter(w => w.userId === userId);
  }

  async addToWatchlist(userId: string, stockId: string): Promise<Watchlist> {
    const existing = this.watchlist.find(w => w.userId === userId && w.stockId === stockId);
    if (existing) {
      return existing;
    }
    const item: Watchlist = {
      id: crypto.randomUUID(),
      userId,
      stockId,
      addedAt: new Date(),
    };
    this.watchlist.push(item);
    return item;
  }

  async removeFromWatchlist(userId: string, stockId: string): Promise<void> {
    this.watchlist = this.watchlist.filter(w => !(w.userId === userId && w.stockId === stockId));
  }

  async clearWatchlist(userId: string): Promise<void> {
    this.watchlist = this.watchlist.filter(w => w.userId !== userId);
  }

  async getPriceHistory(stockId: string): Promise<PriceHistory[]> {
    return this.priceHistory.filter(ph => ph.stockId === stockId);
  }

  async createPriceHistory(insertHistory: InsertPriceHistory): Promise<PriceHistory> {
    const history: PriceHistory = {
      id: crypto.randomUUID(),
      ...insertHistory,
    };
    this.priceHistory.push(history);
    return history;
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(email: string): Promise<User | undefined> {
    if (!db) throw new Error("Database not available");
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    if (!db) throw new Error("Database not available");
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getStocks(): Promise<Stock[]> {
    if (!db) throw new Error("Database not available");
    return await db.select().from(stocks);
  }

  async getStock(id: string): Promise<Stock | undefined> {
    if (!db) throw new Error("Database not available");
    const [stock] = await db.select().from(stocks).where(eq(stocks.id, id));
    return stock || undefined;
  }

  async createStock(insertStock: InsertStock): Promise<Stock> {
    if (!db) throw new Error("Database not available");
    const [stock] = await db
      .insert(stocks)
      .values(insertStock)
      .returning();
    return stock;
  }

  async getFinancials(stockId: string): Promise<Financial[]> {
    if (!db) throw new Error("Database not available");
    return await db.select().from(financials).where(eq(financials.stockId, stockId));
  }

  async getAllFinancials(): Promise<Financial[]> {
    if (!db) throw new Error("Database not available");
    return await db.select().from(financials);
  }

  async createFinancial(insertFinancial: InsertFinancial): Promise<Financial> {
    if (!db) throw new Error("Database not available");
    const [financial] = await db
      .insert(financials)
      .values(insertFinancial)
      .returning();
    return financial;
  }

  async getQuarterlyResults(stockId: string): Promise<QuarterlyResult[]> {
    if (!db) throw new Error("Database not available");
    return await db.select().from(quarterlyResults).where(eq(quarterlyResults.stockId, stockId));
  }

  async createQuarterlyResult(insertResult: InsertQuarterlyResult): Promise<QuarterlyResult> {
    if (!db) throw new Error("Database not available");
    const [result] = await db
      .insert(quarterlyResults)
      .values(insertResult)
      .returning();
    return result;
  }

  async getWatchlist(userId: string): Promise<Watchlist[]> {
    if (!db) throw new Error("Database not available");
    return await db.select().from(watchlist).where(eq(watchlist.userId, userId));
  }

  async addToWatchlist(userId: string, stockId: string): Promise<Watchlist> {
    if (!db) throw new Error("Database not available");
    const [item] = await db
      .insert(watchlist)
      .values({ userId, stockId })
      .returning();
    return item;
  }

  async removeFromWatchlist(userId: string, stockId: string): Promise<void> {
    if (!db) throw new Error("Database not available");
    await db.delete(watchlist).where(
      and(eq(watchlist.userId, userId), eq(watchlist.stockId, stockId))
    );
  }

  async clearWatchlist(userId: string): Promise<void> {
    if (!db) throw new Error("Database not available");
    await db.delete(watchlist).where(eq(watchlist.userId, userId));
  }

  async getPriceHistory(stockId: string): Promise<PriceHistory[]> {
    if (!db) throw new Error("Database not available");
    return await db.select().from(priceHistory).where(eq(priceHistory.stockId, stockId));
  }

  async createPriceHistory(insertHistory: InsertPriceHistory): Promise<PriceHistory> {
    if (!db) throw new Error("Database not available");
    const [history] = await db
      .insert(priceHistory)
      .values(insertHistory)
      .returning();
    return history;
  }
}

// Use in-memory storage if database is not available
export const storage = db ? new DatabaseStorage() : new MemStorage();
