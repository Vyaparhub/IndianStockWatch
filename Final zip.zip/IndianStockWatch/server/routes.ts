import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWatchlistSchema } from "@shared/schema";
import { angelOneAPI } from "./angelone-api";

// Extend Express Session to include user data
declare global {
  namespace Express {
    interface Session {
      user?: {
        id: string;
        email: string;
        firstName?: string;
        lastName?: string;
      };
    }
  }
}

// Mock data generators
function generatePriceHistory(stockSymbol: string, basePrice: number) {
  const history = [];
  const days = 90;
  
  for (let i = days; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    // Generate realistic price movements
    const volatility = 0.02;
    const trend = -0.0001;
    const randomChange = (Math.random() - 0.5) * 2 * volatility;
    const priceChange = basePrice * (trend + randomChange);
    const dayPrice = Math.max(basePrice + priceChange * i, basePrice * 0.7);
    
    history.push({
      id: `${stockSymbol}-${date.toISOString()}`,
      stockId: stockSymbol,
      date: date,
      price: dayPrice.toFixed(2),
    });
  }
  
  return history;
}

function generateFinancials(stockSymbol: string, peRatio: number) {
  const currentYear = new Date().getFullYear();
  
  return [
    {
      id: `${stockSymbol}-2024`,
      stockId: stockSymbol,
      revenue: (Math.random() * 100000 + 50000).toFixed(2),
      profit: (Math.random() * 20000 + 5000).toFixed(2),
      eps: ((Math.random() * 50 + 10) / peRatio).toFixed(2),
      roe: (Math.random() * 30 + 10).toFixed(2),
      debtToEquity: (Math.random() * 2 + 0.2).toFixed(2),
      year: currentYear,
    },
    {
      id: `${stockSymbol}-2023`,
      stockId: stockSymbol,
      revenue: (Math.random() * 90000 + 45000).toFixed(2),
      profit: (Math.random() * 18000 + 4500).toFixed(2),
      eps: ((Math.random() * 45 + 8) / peRatio).toFixed(2),
      roe: (Math.random() * 28 + 9).toFixed(2),
      debtToEquity: (Math.random() * 2.2 + 0.3).toFixed(2),
      year: currentYear - 1,
    },
  ];
}

function generateQuarterlyResults(stockSymbol: string, peRatio: number) {
  const quarters = ["Q1", "Q2", "Q3", "Q4"];
  const currentYear = new Date().getFullYear();
  const results = [];
  
  // Current year quarters
  for (const quarter of quarters) {
    results.push({
      id: `${stockSymbol}-${quarter}-${currentYear}`,
      stockId: stockSymbol,
      quarter,
      year: currentYear,
      revenue: (Math.random() * 25000 + 10000).toFixed(2),
      profit: (Math.random() * 5000 + 1000).toFixed(2),
      eps: ((Math.random() * 15 + 3) / peRatio).toFixed(2),
    });
  }
  
  // Previous year first two quarters
  for (const quarter of quarters.slice(0, 2)) {
    results.push({
      id: `${stockSymbol}-${quarter}-${currentYear - 1}`,
      stockId: stockSymbol,
      quarter,
      year: currentYear - 1,
      revenue: (Math.random() * 23000 + 9000).toFixed(2),
      profit: (Math.random() * 4500 + 900).toFixed(2),
      eps: ((Math.random() * 13 + 2.5) / peRatio).toFixed(2),
    });
  }
  
  return results;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication Routes
  app.post("/api/signup", async (req, res) => {
    try {
      const { email, password, firstName, lastName } = req.body;
      
      if (!email || !password || !firstName || !lastName) {
        return res.status(400).json({ error: "All fields required" });
      }

      const { insertUserSchema } = await import("@shared/schema");
      const result = insertUserSchema.safeParse({
        email,
        password,
        firstName,
        lastName,
      });

      if (!result.success) {
        return res.status(400).json({ error: result.error.errors[0].message });
      }

      // Check if user already exists
      const existingUser = await storage.getUser(email);
      if (existingUser) {
        return res.status(409).json({ error: "Email already registered" });
      }

      // Create new user
      const user = await storage.createUser(result.data);
      
      // Store user in session
      if (req.session) {
        req.session.user = {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
        };
      }
      
      res.status(201).json({ user: req.session?.user });
    } catch (error) {
      console.error("Signup error:", error);
      res.status(500).json({ error: "Signup failed" });
    }
  });

  app.post("/api/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password required" });
      }
      
      // Find user by email
      const user = await storage.getUser(email);
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
      
      // Store user in session
      if (req.session) {
        req.session.user = {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
        };
      }
      
      res.json({ user: req.session?.user });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });

  app.post("/api/logout", (req, res) => {
    try {
      req.session.destroy((err) => {
        if (err) {
          return res.status(500).json({ error: "Logout failed" });
        }
        res.json({ success: true });
      });
    } catch (error) {
      console.error("Logout error:", error);
      res.status(500).json({ error: "Logout failed" });
    }
  });

  app.get("/api/auth/user", (req, res) => {
    try {
      if (req.session?.user) {
        res.json(req.session.user);
      } else {
        res.status(401).json({ error: "Not authenticated" });
      }
    } catch (error) {
      console.error("Auth check error:", error);
      res.status(500).json({ error: "Auth check failed" });
    }
  });

  // Stocks Routes
  app.get("/api/stocks", async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const pageSize = parseInt(req.query.pageSize as string) || 50;
      const search = (req.query.search as string) || "";
      const exchange = (req.query.exchange as string) || "";
      const index = (req.query.index as string) || "";

      let result;
      if (search) {
        result = await angelOneAPI.searchStocks(search, page, pageSize);
      } else if (exchange && (exchange === "NSE" || exchange === "BSE")) {
        result = await angelOneAPI.getStocksByExchange(exchange as "NSE" | "BSE", page, pageSize);
      } else if (index && index !== "ALL") {
        result = await angelOneAPI.fetchStocksPaginated(page, pageSize, index);
      } else {
        result = await angelOneAPI.fetchStocksPaginated(page, pageSize);
      }

      // Transform Angel One data to match our schema
      const stocks = result.stocks.map(stock => ({
        id: stock.symbol,
        name: stock.name,
        symbol: stock.symbol,
        price: stock.price.toString(),
        change: stock.change.toString(),
        changePercent: stock.changePercent.toString(),
        volume: stock.volume.toString(),
        marketCap: stock.marketCap.toString(),
        peRatio: stock.peRatio.toString(),
        sector: stock.sector,
        exchange: stock.exchange,
        indices: stock.indices,
      }));

      res.json({
        stocks,
        pagination: {
          total: result.total,
          page: result.page,
          pageSize: result.pageSize,
          hasMore: result.hasMore,
        },
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stocks" });
    }
  });

  app.get("/api/indices", async (req, res) => {
    try {
      const indices = [
        { id: "NIFTY50", name: "Nifty 50", description: "Top 50 companies" },
        { id: "NIFTY100", name: "Nifty 100", description: "Top 100 companies" },
        { id: "NIFTY200", name: "Nifty 200", description: "Top 200 companies" },
        { id: "NIFTYNEXT50", name: "Nifty Next 50", description: "Next 50 companies" },
        { id: "NIFTYBANK", name: "Nifty Bank", description: "Banking stocks" },
        { id: "NIFTYFINANCIALSERVICES", name: "Nifty Financial Services", description: "Financial services" },
        { id: "NIFTYMIDCAP100", name: "Nifty Midcap 100", description: "Midcap 100 stocks" },
        { id: "SENSEX", name: "Sensex", description: "BSE Sensex index" },
        { id: "BSE100", name: "BSE 100", description: "BSE top 100 stocks" },
      ];
      res.json(indices);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch indices" });
    }
  });

  app.get("/api/stocks/:id", async (req, res) => {
    try {
      const stockId = req.params.id.toUpperCase();
      const result = await angelOneAPI.fetchStocksPaginated(1, 1000);
      const stock = result.stocks.find(s => s.symbol === stockId);
      if (!stock) {
        return res.status(404).json({ error: "Stock not found" });
      }
      res.json(stock);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stock" });
    }
  });

  app.get("/api/stocks/:id/financials", async (req, res) => {
    try {
      const idOrSymbol = req.params.id;
      console.log(`[FINANCIALS] Fetching for: ${idOrSymbol}`);
      
      // First try as direct ID
      let financials = await storage.getFinancials(idOrSymbol);
      
      if (financials.length === 0) {
        // Try to find stock by symbol and get its ID
        const allStocks = await storage.getStocks();
        const stock = allStocks.find(s => s.symbol?.toUpperCase() === idOrSymbol.toUpperCase());
        if (stock) {
          financials = await storage.getFinancials(stock.id);
        }
      }
      
      // If still no data, generate mock data
      if (financials.length === 0) {
        console.log(`[FINANCIALS] No database data, generating mock for: ${idOrSymbol}`);
        
        // Get stock data to use PE ratio
        const result = await angelOneAPI.fetchStocksPaginated(1, 1000);
        const stockData = result.stocks.find(s => s.symbol === idOrSymbol.toUpperCase());
        const peRatio = stockData?.peRatio || 20;
        
        financials = generateFinancials(idOrSymbol, peRatio);
        console.log(`[FINANCIALS] Generated ${financials.length} mock records`);
      }
      
      res.json(financials);
    } catch (error) {
      console.error("Error fetching financials:", error);
      res.status(500).json({ error: "Failed to fetch financials" });
    }
  });

  app.get("/api/stocks/:id/quarterly", async (req, res) => {
    try {
      const idOrSymbol = req.params.id;
      console.log(`[QUARTERLY] Fetching for: ${idOrSymbol}`);
      
      // First try as direct ID
      let results = await storage.getQuarterlyResults(idOrSymbol);
      
      if (results.length === 0) {
        // Try to find stock by symbol and get its ID
        const allStocks = await storage.getStocks();
        const stock = allStocks.find(s => s.symbol?.toUpperCase() === idOrSymbol.toUpperCase());
        if (stock) {
          results = await storage.getQuarterlyResults(stock.id);
        }
      }
      
      // If still no data, generate mock data
      if (results.length === 0) {
        console.log(`[QUARTERLY] No database data, generating mock for: ${idOrSymbol}`);
        
        // Get stock data to use PE ratio
        const result = await angelOneAPI.fetchStocksPaginated(1, 1000);
        const stockData = result.stocks.find(s => s.symbol === idOrSymbol.toUpperCase());
        const peRatio = stockData?.peRatio || 20;
        
        results = generateQuarterlyResults(idOrSymbol, peRatio);
        console.log(`[QUARTERLY] Generated ${results.length} mock records`);
      }
      
      res.json(results);
    } catch (error) {
      console.error("Error fetching quarterly results:", error);
      res.status(500).json({ error: "Failed to fetch quarterly results" });
    }
  });

  app.get("/api/stocks/:id/history", async (req, res) => {
    try {
      const idOrSymbol = req.params.id;
      console.log(`[HISTORY] Fetching for: ${idOrSymbol}`);
      
      // First try as direct ID
      let history = await storage.getPriceHistory(idOrSymbol);
      
      if (history.length === 0) {
        // Try to find stock by symbol and get its ID
        const allStocks = await storage.getStocks();
        const stock = allStocks.find(s => s.symbol?.toUpperCase() === idOrSymbol.toUpperCase());
        if (stock) {
          history = await storage.getPriceHistory(stock.id);
        }
      }
      
      // If still no data, generate mock price history
      if (history.length === 0) {
        console.log(`[HISTORY] No database data, generating mock for: ${idOrSymbol}`);
        
        // Get current stock price from Angel One API
        const result = await angelOneAPI.fetchStocksPaginated(1, 1000);
        const stockData = result.stocks.find(s => s.symbol === idOrSymbol.toUpperCase());
        const basePrice = stockData?.price || 100;
        
        history = generatePriceHistory(idOrSymbol, basePrice);
        console.log(`[HISTORY] Generated ${history.length} mock price records`);
      }
      
      res.json(history);
    } catch (error) {
      console.error("Error fetching price history:", error);
      res.status(500).json({ error: "Failed to fetch price history" });
    }
  });

  app.get("/api/financials", async (_req, res) => {
    try {
      const financials = await storage.getAllFinancials();
      res.json(financials);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch financials" });
    }
  });

  app.get("/api/watchlist", async (_req, res) => {
    try {
      res.json([]);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch watchlist" });
    }
  });

  app.post("/api/watchlist", async (req, res) => {
    try {
      res.status(201).json({ id: "local", ...req.body });
    } catch (error) {
      res.status(500).json({ error: "Failed to add to watchlist" });
    }
  });

  app.delete("/api/watchlist/:stockId", async (req, res) => {
    try {
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to remove from watchlist" });
    }
  });

  app.delete("/api/watchlist", async (_req, res) => {
    try {
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to clear watchlist" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
