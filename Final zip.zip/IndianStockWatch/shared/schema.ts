import { sql } from "drizzle-orm";
import { pgTable, text, varchar, numeric, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const stocks = pgTable("stocks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  symbol: text("symbol").notNull().unique(),
  price: numeric("price", { precision: 12, scale: 2 }).notNull(),
  change: numeric("change", { precision: 12, scale: 2 }).notNull(),
  changePercent: numeric("change_percent", { precision: 8, scale: 2 }).notNull(),
  volume: numeric("volume", { precision: 15, scale: 0 }).notNull(),
  marketCap: numeric("market_cap", { precision: 15, scale: 2 }).notNull(),
  peRatio: numeric("pe_ratio", { precision: 8, scale: 2 }),
  sector: text("sector").notNull(),
  exchange: text("exchange").notNull(),
});

export const financials = pgTable("financials", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  stockId: varchar("stock_id").notNull().references(() => stocks.id, { onDelete: "cascade" }),
  revenue: numeric("revenue", { precision: 15, scale: 2 }).notNull(),
  profit: numeric("profit", { precision: 15, scale: 2 }).notNull(),
  eps: numeric("eps", { precision: 12, scale: 2 }).notNull(),
  roe: numeric("roe", { precision: 8, scale: 2 }).notNull(),
  debtToEquity: numeric("debt_to_equity", { precision: 8, scale: 2 }).notNull(),
  year: integer("year").notNull(),
});

export const quarterlyResults = pgTable("quarterly_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  stockId: varchar("stock_id").notNull().references(() => stocks.id, { onDelete: "cascade" }),
  quarter: text("quarter").notNull(),
  year: integer("year").notNull(),
  revenue: numeric("revenue", { precision: 15, scale: 2 }).notNull(),
  profit: numeric("profit", { precision: 15, scale: 2 }).notNull(),
  eps: numeric("eps", { precision: 12, scale: 2 }).notNull(),
});

export const watchlist = pgTable("watchlist", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  stockId: varchar("stock_id").notNull().references(() => stocks.id, { onDelete: "cascade" }),
  addedAt: timestamp("added_at").notNull().defaultNow(),
});

export const priceHistory = pgTable("price_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  stockId: varchar("stock_id").notNull().references(() => stocks.id, { onDelete: "cascade" }),
  date: timestamp("date").notNull(),
  price: numeric("price", { precision: 12, scale: 2 }).notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
}).extend({
  email: z.string().email("Invalid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
});

export const insertStockSchema = createInsertSchema(stocks).omit({
  id: true,
});

export const insertFinancialSchema = createInsertSchema(financials).omit({
  id: true,
});

export const insertQuarterlyResultSchema = createInsertSchema(quarterlyResults).omit({
  id: true,
});

export const insertWatchlistSchema = createInsertSchema(watchlist).omit({
  id: true,
  addedAt: true,
});

export const insertPriceHistorySchema = createInsertSchema(priceHistory).omit({
  id: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Stock = typeof stocks.$inferSelect;
export type InsertStock = z.infer<typeof insertStockSchema>;

export type Financial = typeof financials.$inferSelect;
export type InsertFinancial = z.infer<typeof insertFinancialSchema>;

export type QuarterlyResult = typeof quarterlyResults.$inferSelect;
export type InsertQuarterlyResult = z.infer<typeof insertQuarterlyResultSchema>;

export type Watchlist = typeof watchlist.$inferSelect;
export type InsertWatchlist = z.infer<typeof insertWatchlistSchema>;

export type PriceHistory = typeof priceHistory.$inferSelect;
export type InsertPriceHistory = z.infer<typeof insertPriceHistorySchema>;

export type StockWithFinancials = Stock & {
  financials: Financial[];
  quarterlyResults: QuarterlyResult[];
  priceHistory: PriceHistory[];
};
